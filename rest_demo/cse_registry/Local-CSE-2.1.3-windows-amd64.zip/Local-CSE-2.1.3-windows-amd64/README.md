# Local-CSE 2.0 快速开始
这个快速开始手册是帮忙您快速在您的电脑上如何使用 CSE。

## Step 1. 预备环境准备
使用Local CSE前，请确认环境是否满足以下要求：

- OS: Linux/Unix/Windows 64 bit
- Arch: x86/arm
- Browser: Chrome, Safari, Edge

## Step 2. 启动 CSE
下载Local-CSE压缩包，如 Local-CSE-$version.zip，执行以下命令解压压缩包到当前目录。
```shell
unzip Local-CSE-$version.zip -d Local-CSE
cd Local-CSE
```

### Linux/Unix

```shell
nohup sh start.sh >/dev/null 2>&1 &
```

### Windows
双击目录下的cse.exe文件启动。

## Step 3. 服务注册&发现和配置管理
服务注册
```shell
curl -X POST 'http://127.0.0.1:30100/v4/default/registry/microservices' -d '{"service":{"serviceName":"Demo"}}'
```

服务发现
```shell
curl -X GET 'http://127.0.0.1:30100/v4/default/registry/instances?appId=default&serviceName=Demo'
```

新建配置
```shell
curl -H 'Content-Type: application/json' -X POST 'http://127.0.0.1:30110/v1/default/kie/kv' -d '{"key":"spring.test","value":"{\"name\":\"demo\"}","value_type":"json","status":"enabled"}'
```

获取配置
```shell
curl -X GET 'http://127.0.0.1:30110/v1/default/kie/kv?key=spring.test'
```

## Step 4. 停止 CSE

### Linux/Unix
```shell
sh stop.sh
```

### Windows
关闭命令行窗口。